﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR_22._106_Kopylov_variant_3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
            Massiv.Visibility = Visibility.Hidden;
            Arr.Visibility = Visibility.Hidden;
            SortArr.Visibility = Visibility.Hidden;
            SortMass.Visibility = Visibility.Hidden;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Massiv.Visibility = Visibility.Visible;
                Arr.Visibility = Visibility.Visible;
                SortArr.Visibility = Visibility.Visible;
                SortMass.Visibility = Visibility.Visible;

                int size = int.Parse(tbSizeArr.Text);
                int ot = int.Parse(tbOt.Text);
                int kon = int.Parse(tbDo.Text);

                Random random = new Random();

                int[] array = new int[size];

                for(int i = 0; i < size; i++)
                {
                    array[i] = random.Next(ot, kon + 1);
                }

                string result = string.Join(" ", array);

                Arr.Content = result;

                int[] sortArray = array;

                for (int i = 0; i < size - 1; i++)
                {
                    for (int j = 0; j < size - i - 1; j++)
                    {
                        if (sortArray[j] % 2 != 0 && sortArray[j + 1] % 2 == 0)
                        {
                            int temp = sortArray[j];
                            sortArray[j] = sortArray[j + 1];
                            sortArray[j + 1] = temp;
                        }
                    }
                }

                string result2 = string.Join(" ", sortArray);

                SortArr.Content = result2;
            }
            catch(FormatException)
            {
                MessageBox.Show("Пожалуйтса, введите корректные значения для размера массива и его диапазона.", "Ошибка", MessageBoxButton.OK);
                Massiv.Visibility = Visibility.Hidden;
                Arr.Visibility = Visibility.Hidden;
                SortArr.Visibility = Visibility.Hidden;
                SortMass.Visibility = Visibility.Hidden;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK);
                Massiv.Visibility = Visibility.Hidden;
                Arr.Visibility = Visibility.Hidden;
                SortArr.Visibility = Visibility.Hidden;
                SortMass.Visibility = Visibility.Hidden;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
           
        }         
    }
}
